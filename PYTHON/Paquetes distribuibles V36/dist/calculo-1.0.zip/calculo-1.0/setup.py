from setuptools import setup


setup(

	name="calculo",
	version="1.0",
	description="Calculos básicos matemáticos",
	author="kevQL",
	packages=["paquetesV35","paquetesV35.calculo"]

	)